"""Specifies the current version number of OpenCOOD."""

__version__ = "0.1.0"
